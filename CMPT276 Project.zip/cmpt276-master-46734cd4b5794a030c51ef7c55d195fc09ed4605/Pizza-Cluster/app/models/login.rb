class Login < ApplicationRecord
end
