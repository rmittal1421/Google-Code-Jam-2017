class InfoController < ApplicationController
end
