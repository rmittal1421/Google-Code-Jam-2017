class MenuController < ApplicationController
	def show
		
	end
end
