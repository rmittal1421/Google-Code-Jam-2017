class PizzaclusterController < ApplicationController
  def index
  end
end
