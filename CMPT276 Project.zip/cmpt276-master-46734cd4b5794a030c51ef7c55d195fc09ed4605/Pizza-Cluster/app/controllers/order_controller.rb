class OrderController < ApplicationController
	def show

	end
end
